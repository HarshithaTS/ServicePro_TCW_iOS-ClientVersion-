//
//  ServiceTaskEdit.h
//  ServicePro
//
//  Created by GSS Mysore on 07/02/13.
//
//

#import <UIKit/UIKit.h>

@interface ServiceTaskEdit : UIViewController
{
IBOutlet UIScrollView *scrollView;
    IBOutlet UIView *myView;
    IBOutlet UITextView *txtView;

}
@end
