//
//  ViewController.m
//  ServicePro
//
//  Created by gss on 2/9/13.
//
//

#import "MapViewController.h"
#import "ServiceManagementData.h"

@interface MapViewController ()

@end

@implementation MapViewController

@synthesize coords = _coords;
@synthesize currentLocation = _currentLocation;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    [self findCurrentLocation];
    _coords = [self addressLocation];

    [self showGoogleWebMap];
    // Do any additional setup after loading the view from its nib.
}

-(void)findCurrentLocation
{
//    CLLocationManager *locationManager = [[CLLocationManager alloc] init];
    //    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    //    locationManager.distanceFilter = kCLDistanceFilterNone;
    //    locationManager.delegate = self;
    //    [locationManager startUpdatingLocation];
    //    MKMapView *mapview = [[MKMapView alloc]init];
    //    CLLocationCoordinate2D location = [[[mapview userLocation] location] coordinate];
    //    NSLog(@"Location found from Map: %f %f",location.latitude,location.longitude);

//    locationManager = [[CLLocationManager alloc] init];
//
//    if ([locationManager locationServicesEnabled])
//    {
//        locationManager.delegate = self;
//        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
//        locationManager.distanceFilter = kCLDistanceFilterNone;
//        [locationManager startUpdatingLocation];
//    }
//    CLLocation *location = [locationManager location];
//    _currentLocation = [location coordinate];
//    
//    NSString *str=[[NSString alloc] initWithFormat:@" latitude:%f longitude:%f",_currentLocation.latitude,_currentLocation.longitude];
//    NSLog(@"%@",str);
    
}


-(CLLocationCoordinate2D) addressLocation {
    
    ServiceManagementData *objServiceManagementData = [ServiceManagementData sharedManager];
    
    NSString *addressString = [NSString stringWithFormat:@"%@ %@ %@ %@",
                               [objServiceManagementData.taskDataDictionary objectForKey:@"STRAS"],
                               [objServiceManagementData.taskDataDictionary objectForKey:@"ORT01"],
                               [objServiceManagementData.taskDataDictionary objectForKey:@"PSTLZ"],
                               [objServiceManagementData.taskDataDictionary objectForKey:@"LAND1"]];
    NSLog(@"ADDeRSS STRING:%@", [objServiceManagementData.taskDataDictionary objectForKey:@"STRAS"]);
	NSString *urlString = [NSString stringWithFormat:@"http://maps.google.com/maps/geo?q=%@&output=csv",
                           [addressString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
	NSString *locationString = [NSString stringWithContentsOfURL:[NSURL URLWithString:urlString]];
	NSArray *listItems = [locationString componentsSeparatedByString:@","];
	NSLog(@"response from google : %@", listItems);
	double latitude = 0.0;
	double longitude = 0.0;
	
	if([listItems count] >= 4 && [[listItems objectAtIndex:0] isEqualToString:@"200"]) {
		latitude = [[listItems objectAtIndex:2] floatValue];
		longitude = [[listItems objectAtIndex:3] floatValue];
	}
	else {
        if ([[listItems objectAtIndex:0] isEqualToString:@"602"]) {
            UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"Alert" message:@"Address is not valid. Unable to load Map." delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:nil];
            [av show];
            [av release];
        }
		
	}
	
	CLLocationCoordinate2D location;
	location.latitude = latitude;
	location.longitude = longitude;
	
	return location;
	
}


- (void)showGoogleWebMap {
    
    NSLog(@"destination: %f, %f", _coords.latitude, _coords.longitude);
    
    UIWebView *webView = [[UIWebView alloc] initWithFrame:self.view.bounds];
	webView.delegate= self;
    NSString *fullUrl = [NSString stringWithFormat: @"http://maps.google.com/maps?saddr=%f,%f&daddr=%f,%f",_currentLocation.latitude,_currentLocation.longitude,_coords.latitude,_coords.longitude];
    
    NSURL *url = [NSURL URLWithString:fullUrl];
    NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
    NSLog(@"request: %@", requestObj);
    [webView loadRequest:requestObj];
    [self setView:webView];
    
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
	printf("\n started");
    
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
	printf("\n stopped");
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation :(UIInterfaceOrientation)interfaceOrientation {
    
    return YES;
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
